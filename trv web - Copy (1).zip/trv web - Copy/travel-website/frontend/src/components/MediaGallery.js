import React, { useState, useEffect } from 'react';
import './MediaGallery.css';

const MediaGallery = () => {
    const [scrollingDown, setScrollingDown] = useState(true);
    const [currentSection, setCurrentSection] = useState(0);
    const [isChanging, setIsChanging] = useState(false);
    const [isThrottled, setIsThrottled] = useState(false);

    // Sections array to control the scroll transition (empty sections)
    const sections = [ {}, {}, {} ]; // Empty content

    // Handle scroll event with slide-in effect
    useEffect(() => {
        const handleScroll = (e) => {
            if (isChanging || isThrottled) return; // Prevent rapid changes

            if (e.deltaY > 0) {
                setScrollingDown(true);
            } else {
                setScrollingDown(false);
            }

            setIsChanging(true); // Start the transition

            setTimeout(() => {
                if (scrollingDown && currentSection < sections.length - 1) {
                    setCurrentSection(currentSection + 1);
                } else if (!scrollingDown && currentSection > 0) {
                    setCurrentSection(currentSection - 1);
                }

                setIsChanging(false); // End the transition
            }, 800); // Adjust delay for a smoother effect

            // Throttle the scroll event
            setIsThrottled(true);
            setTimeout(() => setIsThrottled(false), 600); // Delay for throttling
        };

        window.addEventListener('wheel', handleScroll, { passive: true });

        return () => {
            window.removeEventListener('wheel', handleScroll);
        };
    }, [currentSection, scrollingDown, isChanging, isThrottled]);

    return (
        <div className="media-gallery-container">
            {/* Empty section with transition */}
            <div
                className={`empty-section ${scrollingDown ? 'scrolling-down' : 'scrolling-up'}`}
            >
                {/* Content is empty, just for visual transition */}
            </div>
        </div>
    );
};

export default MediaGallery;
