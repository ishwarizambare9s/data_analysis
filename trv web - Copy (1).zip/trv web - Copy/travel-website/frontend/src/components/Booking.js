import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './Booking.css';

const Booking = () => {
  const { destinationId } = useParams();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    destinationId: destinationId,
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      setError('Please fill in all fields.');
      return;
    }
    try {
      setLoading(true);
      await axios.post('http://localhost:5000/api/bookings', formData);
      setSubmitted(true);
      setError('');
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (submitted) {
    return (
      <div className="booking-success">
        <h1>🎉 Booking Successful!</h1>
        <p>Thank you for choosing us. We'll contact you shortly.</p>
      </div>
    );
  }

  return (
    <div className="booking-form-container">
      <h1>Book Destination #{destinationId}</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Processing...' : 'Confirm Booking'}
        </button>
      </form>
    </div>
  );
};

export default Booking;