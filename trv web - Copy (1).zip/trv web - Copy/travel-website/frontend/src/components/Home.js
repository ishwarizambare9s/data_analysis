import React, { useEffect, useRef } from 'react';
import './Home.css';

const Home = () => {
    const homeRef = useRef(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate');
                        observer.unobserve(entry.target); // Stop observing after animation starts
                    }
                });
            },
            {
                threshold: 0.5, // Trigger when 50% of the element is visible
            }
        );

        if (homeRef.current) {
            observer.observe(homeRef.current);
        }

        return () => {
            if (homeRef.current) {
                observer.unobserve(homeRef.current);
            }
        };
    }, []);

    return (
        <div className="home" ref={homeRef}>
            <h2>Welcome to the Travel Website</h2>
            <p>Your adventure starts here! Explore beautiful destinations across the world.</p>
            <h3>Discover the World with Us!</h3>
        </div>
    );
};

export default Home;