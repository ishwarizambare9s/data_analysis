import React from 'react';
import './DestinationCard.css';

const DestinationCard = ({ destination }) => {
  return (
    <div className="destination-card">
      <img src={destination.image} alt={destination.name} />
      <h2>{destination.name}</h2>
      <p>{destination.description}</p>
    </div>
  );
};

export default DestinationCard;
