import React, { useState } from 'react';
import './Search.css';

const Search = ({ destinations, setFilteredDestinations }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (event) => {
    const term = event.target.value;
    setSearchTerm(term);

    const filtered = destinations.filter(destination => 
      destination.name.toLowerCase().includes(term.toLowerCase()) ||
      destination.description.toLowerCase().includes(term.toLowerCase())
    );

    setFilteredDestinations(filtered);
  };

  return (
    <div className="search-container">
      <input
        type="text"
        className="search-input"
        placeholder="Search destinations..."
        value={searchTerm}
        onChange={handleSearch}
      />
    </div>
  );
};

export default Search;
