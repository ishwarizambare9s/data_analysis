import React, { useEffect, useState } from 'react';
import axios from 'axios';
import DestinationCard from './DestinationCard';
import './DestinationList.css';

const DestinationList = () => {
    const [destinations, setDestinations] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchDestinations = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/destinations');
                setDestinations(response.data);
            } catch (error) {
                console.error('Error fetching destinations:', error);
                setError('Failed to load destinations.');
            }
        };
        fetchDestinations();
    }, []);

    if (error) {
        return <div className="error">{error}</div>;
    }

    return (
        <div className="destination-cards">
            {destinations.map((destination) => (
                <DestinationCard key={destination._id} destination={destination} />
            ))}
        </div>
    );
};

export default DestinationList;