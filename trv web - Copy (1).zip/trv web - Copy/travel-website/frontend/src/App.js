import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import DestinationList from './components/DestinationList';
import Booking from './components/Booking';
import BookingsList from './components/BookingsList';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app-container">
        <div className="video-background">
          <video autoPlay loop muted className="background-video">
            <source src="/video/v1.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="overlay-text">
            <h1>Explore the World</h1>
            <p>Your journey starts here</p>
          </div>
        </div>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/destinations" element={<DestinationList />} />
          <Route path="/booking/:destinationId" element={<Booking />} />
          <Route path="/bookings" element={<BookingsList />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;