# Uber Data Analysis with Python

Uber Technologies, Inc., commonly known as Uber, is ans American technology company. Its services include ride-hailing, food delivery, package delivery, couriers, freight tranportation, and through a partnership with Lime, electric bicycle and motorized scooter rental.

But, we will mainly use data regarding Uber ride and use Python to analyse the data.

We wish to answer the below following question:

- Check how long do people travel with Uber?
- What Hour Do Most People take Uber To Their Destination?
- Check The purpose of trips
- Which Day has the highest number of trips
- What are the number of trips per each day?
- What are the trips in the month?
- The starting points of trips. Where do people start boarding their trip from Most?

