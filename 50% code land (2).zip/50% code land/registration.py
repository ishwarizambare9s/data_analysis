import tkinter as tk
from tkinter import messagebox as ms
import sqlite3
from PIL import Image, ImageTk
import re
import random
from subprocess import call

# ------------------------- Main Window Setup -------------------------
window = tk.Tk()
window.geometry("700x700+300+50")
window.title("REGISTRATION FORM")
window.configure(background="grey")

Fullname = tk.StringVar()
address = tk.StringVar()
username = tk.StringVar()
Email = tk.StringVar()
Phoneno = tk.StringVar()
var = tk.IntVar()
age = tk.IntVar()
password = tk.StringVar()
password1 = tk.StringVar()

# ------------------------- Database Setup -------------------------
db = sqlite3.connect('evaluation.db')
cursor = db.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS admin_registration
    (Fullname TEXT, address TEXT, username TEXT, Email TEXT,
     Phoneno TEXT, Gender TEXT, age TEXT, password TEXT)
""")
db.commit()
db.close()


# ------------------------- Password Validation -------------------------
def password_check(passwd):
    SpecialSym = ['$', '@', '#', '%']
    val = True

    if len(passwd) < 6:
        val = False
    if len(passwd) > 20:
        val = False
    if not any(char.isdigit() for char in passwd):
        val = False
    if not any(char.isupper() for char in passwd):
        val = False
    if not any(char.islower() for char in passwd):
        val = False
    if not any(char in SpecialSym for char in passwd):
        val = False

    return val


# ------------------------- Insert Data Function -------------------------
def insert():
    fname = Fullname.get()
    addr = address.get()
    un = username.get()
    email = Email.get()
    mobile = Phoneno.get()
    gender = var.get()
    time = age.get()
    pwd = password.get()
    cnpwd = password1.get()

    db = sqlite3.connect('evaluation.db')
    c = db.cursor()
    c.execute('SELECT * FROM admin_registration WHERE username = ?', (un,))
    user_exists = c.fetchall()

    # Email validation
    regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
    valid_email = re.search(regex, email)

    # ---------------- Validation -----------------
    if fname == "" or fname.isdigit():
        ms.showerror("Error", "Please enter a valid name")
    elif addr == "":
        ms.showerror("Error", "Please enter your address")
    elif not valid_email:
        ms.showerror("Error", "Please enter a valid email")
    elif not mobile.isdigit() or len(mobile) != 10:
        ms.showerror("Error", "Please enter a valid 10-digit phone number")
    elif time <= 0 or time > 100:
        ms.showerror("Error", "Please enter a valid age")
    elif user_exists:
        ms.showerror("Error", "Username already exists! Try another one.")
    elif pwd == "":
        ms.showerror("Error", "Please enter a password")
    elif not password_check(pwd):
        ms.showerror("Error", "Password must contain uppercase, lowercase, number, and special character")
    elif pwd != cnpwd:
        ms.showerror("Error", "Passwords do not match")
    else:
        c.execute("""
            INSERT INTO admin_registration
            (Fullname, address, username, Email, Phoneno, Gender, age, password)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (fname, addr, un, email, mobile, gender, time, pwd))
        db.commit()
        db.close()

        ms.showinfo("Success", "Account created successfully!")
        window.destroy()  # Close current window
        call(["python", "login.py"])  # ✅ Redirect to next page (change filename if needed)


# ------------------------- Background Image -------------------------
image2 = Image.open('b.jpg')
image2 = image2.resize((1700, 1300), Image.LANCZOS)
background_image = ImageTk.PhotoImage(image2)

background_label = tk.Label(window, image=background_image)
background_label.image = background_image
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# ------------------------- Form UI -------------------------
l1 = tk.Label(window, text="Registration Form", font=("Times new roman", 30, "bold"), bg="black", fg="white")
l1.place(x=180, y=40)

fields = [
    ("Full Name :", Fullname, 150),
    ("Address :", address, 200),
    ("E-mail :", Email, 250),
    ("Phone number :", Phoneno, 300),
    ("Age :", age, 400),
    ("User Name :", username, 450),
    ("Password :", password, 500),
    ("Confirm Password :", password1, 550)
]

for label, var, y in fields:
    tk.Label(window, text=label, width=15, font=("Times new roman", 15, "bold"), bg="snow").place(x=100, y=y)
    show = "*" if "Password" in label else ""
    tk.Entry(window, textvariable=var, width=20, font=('', 15), show=show).place(x=330, y=y)

# Gender Section
tk.Label(window, text="Gender :", width=12, font=("Times new roman", 15, "bold"), bg="snow").place(x=130, y=350)
tk.Radiobutton(window, text="Male", padx=5, width=5, bg="snow", font=("bold", 15), variable=var, value=1).place(x=330, y=350)
tk.Radiobutton(window, text="Female", padx=20, width=4, bg="snow", font=("bold", 15), variable=var, value=2).place(x=440, y=350)

# Register Button
tk.Button(window, text="Register", bg="black", font=("", 20), fg="white", width=10, command=insert).place(x=260, y=620)

window.mainloop()
