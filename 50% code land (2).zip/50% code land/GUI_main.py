import tkinter as tk
from PIL import Image, ImageTk

# ==============================================
root = tk.Tk()
root.configure(background="black")

w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("GUI_Main")

# ==============================================================
# Background Image (full window)
background_img = Image.open("main1.jpg")  # Replace with your background image
background_img = background_img.resize((w, h))
background_photo = ImageTk.PhotoImage(background_img)

background_label = tk.Label(root, image=background_photo)
background_label.image = background_photo
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# ==============================================================
# Title Label
label_l2 = tk.Label(root, text="Land Classification ",
                    font=("times", 30, 'bold'),
                    background="green", fg="white", width=70, height=2)
label_l2.place(x=0, y=0)

# ==============================================================
# Slideshow Images
img1 = ImageTk.PhotoImage(Image.open("main1.jpg").resize((w, int(h * 0.8))))
img2 = ImageTk.PhotoImage(Image.open("main2.jpg").resize((w, int(h * 0.8))))
img3 = ImageTk.PhotoImage(Image.open("main3.jpg").resize((w, int(h * 0.8))))

logo_label = tk.Label(root, bg="black")
logo_label.place(x=0, y=200)  # pushed slightly down for better visibility

x = 1

def move():
    global x
    if x == 4:
        x = 1
    if x == 1:
        logo_label.config(image=img1)
    elif x == 2:
        logo_label.config(image=img2)
    elif x == 3:
        logo_label.config(image=img3)
    x += 1
    root.after(2000, move)

move()

# ==============================================================
# Login / Register Frame (moved to upper area)
frame_alpr = tk.LabelFrame(root, text=" --Login & Register-- ",
                           width=800, height=100, bd=5,
                           font=('times', 14, 'bold'),
                           bg="grey", fg="white")
frame_alpr.place(x=(w/2 - 400), y=100)  # Positioned near the top

# ==============================================================
def log():
    from subprocess import call
    call(["python", "login.py"])

def reg():
    from subprocess import call
    call(["python", "registration.py"])

def window():
    root.destroy()

# ==============================================================
button1 = tk.Button(frame_alpr, text="Login", command=log,
                    width=15, height=1, font=('times', 15, 'bold'),
                    bg="red", fg="white")
button1.place(x=170, y=20)

button2 = tk.Button(frame_alpr, text="Registration", command=reg,
                    width=15, height=1, font=('times', 15, 'bold'),
                    bg="green", fg="white")
button2.place(x=470, y=20)

# ==============================================================
root.mainloop()
